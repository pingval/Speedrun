﻿大航海時代IV with PK HDバージョン 日本語版のセーブデータディレクトリへコピー
C:/User/<USERNAME>/Documents/KoeiTecmo/DK4HD/Savedata/ja/

1-8: 1月1日
11-18: 7月1日
21-28: 覇者の証の座標周辺で停泊(1月)
