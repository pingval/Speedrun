* これ is 何

あやせひろみさん作の似非四字熟語を、本家本元の三/四字熟語Flash練習用に勝手に改変したものです。
画像はそのまま流用していますがいわゆる集落民でないとネタが意味不明かもしれません。

主な変更点：
・出題される熟語を元の三/四字熟語Flashと同じに
・テキストを選択不可能にして遊びやすく
・出現頻度ごとに漢字を色分け(気に入らないならCSS弄ってください)
・漢字にマウスを重ねるとその漢字が使用されている熟語を全て表示
・使用熟語絡みのデータを別ファイルに分離

・似非四字熟語(https://dl.dropboxusercontent.com/u/9407653/Applications/4jukugo/4jukugo.html)
・四字熟語Flash(http://www.gamedesign.jp/flash/yojifla/yojifla.html)
・三字熟語Flash(http://www.gamedesign.jp/flash/sanjuku/sanjuku.html)

改変 by ping値(https://twitter.com/pingval)
